public interface subsciber{
    public void update(String news);
}