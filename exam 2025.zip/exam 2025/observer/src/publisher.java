public interface publisher {
    public void addnews(subsciber s);
    public void notify(String  s);
}
