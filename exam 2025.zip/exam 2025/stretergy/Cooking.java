public class Cooking  implements robot{
    public String PerformTask(){
        return "start cooking";
    }
}
