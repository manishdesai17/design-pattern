public class Dancing  implements robot{
    public String PerformTask(){
        return "start dancing";
    }
}
