public class Sleep implements robot {
    public String PerformTask(){
        return "Sleeping...........";
    }
}
