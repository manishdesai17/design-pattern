interface bank {
public void setbank(context state);    
}