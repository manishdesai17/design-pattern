public class Indian_desserts implements desserts {
    public String Create_desserts()
    {
        return "create Indian desserts dish";
    }
}
