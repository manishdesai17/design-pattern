import java.sql.*;

class postgresql implements databaseconnection {
  String con = "";

  public String connect() {
    try {
      con = "postgresql connection succesfully..";
    } catch (Exception e) {
      System.out.println(e);
    }
    return con;
  }

  public String disconnect() {
    try {
      con = "";
    } catch (Exception e) {
      System.out.println(e);
    }
    return con;
  }
}
