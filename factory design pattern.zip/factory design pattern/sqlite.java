import java.sql.*;

class sqlite implements databaseconnection {
    String con = "";

    public String connect() {
        try {
            con = "sqlite connection succesfully..";
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

    public String disconnect() {
        try {
            con = "";
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }
}
