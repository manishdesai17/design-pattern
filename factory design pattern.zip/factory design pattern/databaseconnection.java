import java.sql.Connection;

public interface databaseconnection {

    public String connect();

    public String disconnect();

    // public void selectQuery();

}
