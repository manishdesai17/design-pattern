
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String con = "";
        while (true) {
            System.out.println("Enter Database Name:");
            String dbtype = sc.next();
            databaseconnection data = Factorydatabase.getdatabasetype(dbtype);
            con = data.connect();
            if (con != "") {
                System.out.println(dbtype + " connection successfully.....");
            }
            con = data.disconnect();
            if (con == "") {
                System.out.println(dbtype + " disconnection successfully....");
            }
        }
    }
}