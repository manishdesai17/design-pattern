class SDLCDirector {
    private SDLCBuilder builder;

    public SDLCDirector(SDLCBuilder builder) {
        this.builder = builder;
    }


    public SoftwareProject constructProjects() {
        builder.setRequirements();
        builder.setDesign();
        builder.setDevelopment();
        builder.setTesting();
        builder.setDeployment();
        return builder.build();
    }
}
