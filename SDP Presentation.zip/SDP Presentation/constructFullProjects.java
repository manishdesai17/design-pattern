class constructFullProjects implements SDLCBuilder {
    private SoftwareProject project;

    public constructFullProjects() {
        this.project = new SoftwareProject();
    }

    @Override
    public void setRequirements() {
        project.setRequirements="Gather and analyze client requirements.";
    }

    @Override
    public void setDesign() {
        project.setDesign="Create UML diagrams, architecture, and prototypes.";
    }

    @Override
    public void setDevelopment() {
        project.setDevelopment="Code the application based on design.";
    }

    @Override
    public void setTesting() {
        project.setTesting="Perform unit, integration, and system testing.";
    }

    @Override
    public void setDeployment() {
        project.setDeployment="Deploy the application to production.";
    }

    @Override
    public SoftwareProject build() {
        return this.project;
    }
}
