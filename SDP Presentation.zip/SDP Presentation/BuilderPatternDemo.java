
public class BuilderPatternDemo {
    public static void main(String[] args) {
        SDLCBuilder builder = new constructFullProject();
        SDLCDirector director = new SDLCDirector(builder);
        SoftwareProject project = director.constructProjects();
        project.showProject();

    }
}