import java.io.*;


interface IFileManager {
    boolean createFile(String directory, String fileName) throws IOException;
    boolean writeToFile(String directory, String fileName, String content) throws IOException;
    String readFile(String directory, String fileName) throws IOException;
    boolean deleteFile(String directory, String fileName) throws IOException;
}    