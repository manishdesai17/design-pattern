import java.io.IOException;

public class FileOperationsDemo {
    public static void main(String[] args) {
        String directory = "test_directory";
        String fileName = "sample.txt";

        try {
            // Admin operations
            System.out.println("Admin Operations:");
            IFileManager adminOperations = new ProxyFileManager("admin");
            
            adminOperations.createFile(directory, fileName);
            adminOperations.writeToFile(directory, fileName, "Hello, this is admin content!");
            System.out.println("File content: " + adminOperations.readFile(directory, fileName));
        
            System.out.println("\nUser Operations:");
            IFileManager userOperations = new ProxyFileManager("user");
            
            System.out.println("File content: " + userOperations.readFile(directory, fileName));
            
       
            try {
                userOperations.writeToFile(directory, fileName, "User trying to write");
            } catch (SecurityException e) {
                System.out.println("Error: " + e.getMessage());
            }

            
            try {
                userOperations.deleteFile(directory, fileName);
            } catch (SecurityException e) {
                System.out.println("Error: " + e.getMessage());
            }

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
