import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

class FileManager implements IFileManager {
    @Override
    public boolean createFile(String directory, String fileName) throws IOException {
        File dir = new File(directory);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File file = new File(directory + File.separator + fileName);
        file.createNewFile();
        return true;
    }

    @Override
    public boolean writeToFile(String directory, String fileName, String content) throws IOException {
        File file = new File(directory + File.separator + fileName);
        try (FileWriter writer = new FileWriter(file, true)) {
            writer.write(content + "\n");
           return true;
        }
    }

    @Override
    public String readFile(String directory, String fileName) throws IOException {
        File file = new File(directory + File.separator + fileName);
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }
        return content.toString();
    }

    @Override
    public boolean deleteFile(String directory, String fileName) throws IOException {
        File file = new File(directory + File.separator + fileName);
        if (file.delete()) {
            return true;
        } else {
            throw new IOException("Failed to delete file");
        }
    }
}
