class DatabaseExceptionHandler extends ExceptionHandler {
    @Override
    public void handleException(Exception exception) {
        if (exception instanceof DatabaseException) {
            System.out.println("Database Handler: Handling " + exception.getMessage());
            System.out.println("Action: Attempting database reconnection...");
        } else if (nextHandler != null) {
            System.out.println("Database Handler: Passing to next handler...");
            nextHandler.handleException(exception);
        } else {
            System.out.println("Database Handler: No suitable handler found for " + exception.getMessage());
        }
    }
}