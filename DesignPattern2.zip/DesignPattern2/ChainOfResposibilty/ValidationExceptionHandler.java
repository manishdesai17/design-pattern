class ValidationExceptionHandler extends ExceptionHandler {
    @Override
    public void handleException(Exception exception) {
        if (exception instanceof ValidationException) {
            System.out.println("Validation Handler: Handling " + exception.getMessage());
            System.out.println("Action: Notifying user about invalid input...");
        } else if (nextHandler != null) {
            System.out.println("Validation Handler: Passing to next handler...");
            nextHandler.handleException(exception);
        } else {
            System.out.println("Validation Handler: No suitable handler found for " + exception.getMessage());
        }
    }
}