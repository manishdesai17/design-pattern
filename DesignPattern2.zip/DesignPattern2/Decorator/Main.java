import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;

public class Main {
    public static void main(String[] args) {
        try {
           
            LogInputStrem lis = new LogInputStrem(new FileInputStream("text.txt"));

            // System.out.println(lis.read());
            // System.out.println(lis.read());
            // System.out.println(lis.read());
            // System.out.println(lis.read());
            // System.out.println(lis.read());
            // System.out.println(lis.read());
            // System.out.println(lis.read());
            // System.out.println(lis.read());
            
            // System.out.println(lis.read());
            
            // System.out.println(lis.read());
            
            // System.out.println(lis.read());
            

            // System.out.println(lis.numberOfWords());
            // System.out.println(lis.numberOfCharacter());
            // System.out.println(lis.numberOfLines());
        
           lis.close();
           LogOutputStream los = new LogOutputStream(new FileOutputStream("text.txt"));
           los.write('j');
           los.write('l');
           los.write('j');
           los.write('k');
           System.out.println(los.numberOfCharacter());
          
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
