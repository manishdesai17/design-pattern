public interface Appetizers {

    public String prepar();
}
