public class ChineseDesserts implements Desserts{
    public String prepar()
    {
       return "Mango Pudding";
    }
}
