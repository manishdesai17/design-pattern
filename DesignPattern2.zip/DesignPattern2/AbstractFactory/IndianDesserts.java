public class IndianDesserts implements Desserts{
    public String prepar()
    {
        return "Gulab Jamun";
    }
}
