public interface Desserts
{
    public String prepar();
}