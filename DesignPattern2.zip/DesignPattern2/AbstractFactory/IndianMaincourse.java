public class IndianMaincourse implements Maincourse{
    public String prepar()
    {
       return "Palak Paneer";
    }
}
