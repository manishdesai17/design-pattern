public interface BiteBehavior {
    String bite();
}