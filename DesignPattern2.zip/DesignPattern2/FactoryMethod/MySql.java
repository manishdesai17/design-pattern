import java.sql.Array;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

public class MySql extends DBMS {
    @Override
    //connect to mysql database and return true or false
    public boolean connect(Properties p) throws SQLException {
        boolean re;
        // System.out.println("\n\n -------------url : "+coninfo[0]+"\n user :"+coninfo[1]+" password : "+coninfo[2]);
        con = DriverManager.getConnection(p.getProperty("Mysql-url"),p.getProperty("Mysql-user"),p.getProperty("Mysql-password"));
        if (con == null)
            re = false;
        else
            re = true;
        return re;
    }

    @Override
    //select records from table and return Resultset
    public ResultSet selectRecords(String query) throws SQLException {
        
     
        Statement st = con.createStatement();
        return st.executeQuery(query);
        
    }
}