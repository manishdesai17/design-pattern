import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;


public class Sqlite extends DBMS {
    @Override
     //connect to mysql database and return true or false
    public boolean connect(Properties p) throws SQLException {
        boolean re;
        con = DriverManager.getConnection(p.getProperty("Sqlite-url"));
        if (con == null)
            re = false;
        else
            re = true;
        return re;
    }

    @Override
    //select records from table and return Resultset
    public ResultSet selectRecords(String query) throws SQLException {

        Statement st = con.createStatement();
  
        return st.executeQuery(query);
    }

}
