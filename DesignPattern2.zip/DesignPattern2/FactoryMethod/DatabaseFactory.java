public class DatabaseFactory {

    //based on dbtype , to create object of approprite database class
    public static DBMS getDatabase(String dbtype) throws Exception {
        DBMS db = null;
        if (dbtype.equalsIgnoreCase("MySql"))
            db = new MySql();
        else if (dbtype.equalsIgnoreCase("Sqlite"))
            db = new Sqlite();
        else if(dbtype.equalsIgnoreCase("Postgresql"))
            db= new Postgresql();
        else
            throw new Exception("Database server is not available");
        return db;
    }
}