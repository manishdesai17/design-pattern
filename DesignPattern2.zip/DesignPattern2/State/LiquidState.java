class LiquidState implements WaterState {
    @Override
    public void applyHeat(Water water) {
        System.out.println("Liquid is evaporating to Gas...");
        water.setState(new GasState());
    }
    
    @Override
    public void applyCold(Water water) {
        System.out.println("Liquid is freezing to Ice...");
        water.setState(new SolidState());
    }
}