

import java.util.ArrayList;
import java.util.List;

public class NewsAgency implements NewsAgencySubject {
    private List<NewsObserver> observers = new ArrayList<>();
    private String latestNews;

    @Override
    public void addObserver(NewsObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(NewsObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (NewsObserver observer : observers) {
            observer.update(latestNews);
        }
    }

    public void setNews(String news) {
        this.latestNews = news;
        notifyObservers();
    }
}