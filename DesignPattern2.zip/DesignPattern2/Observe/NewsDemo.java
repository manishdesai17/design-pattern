

public class NewsDemo {
    public static void main(String[] args) {
      
        NewsAgency agency = new NewsAgency();

        TVChannel tv = new TVChannel("CNN");
        NewsWebsite website = new NewsWebsite("Tv9.com");
        NewsWebsite website1 = new NewsWebsite("Divyabhaskar.com");
        agency.addObserver(tv);
        agency.addObserver(website);
        agency.addObserver(website1);
        agency.setNews("Breaking: Sunny weather expected tomorrow!");
        agency.removeObserver(website);
        agency.setNews("Update: Traffic accident reported downtown.");
    } 
}
