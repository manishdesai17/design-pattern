
public class NewsWebsite implements NewsObserver {
    private String domain;

    public NewsWebsite(String domain) {
        this.domain = domain;
    }

    @Override
    public void update(String news) {
        System.out.println("Updating " + domain + " with: " + news);
    }
}