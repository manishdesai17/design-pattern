public interface stretergy{
    public String pay();
}