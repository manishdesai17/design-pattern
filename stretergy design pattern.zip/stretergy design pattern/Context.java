public class Context {
    private stretergy stretergy;

     public void setPaymentStretergy(stretergy stretergy)
     {
        this.stretergy=stretergy;
     }
     public String dopayment()
     {
        return this.stretergy.pay();
     }
}
