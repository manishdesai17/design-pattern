public class UPI implements stretergy{
    String upi="";
    public UPI(){
      upi="Pay by UPI....";
    }
    public String pay()
    {
        return upi;
    }
}
