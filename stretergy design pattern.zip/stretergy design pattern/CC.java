public class CC implements stretergy{
    String cc="";
    public CC(){
        cc="Pay by UPI....";
    }
    public String pay()
    {
        return cc;
    }
}