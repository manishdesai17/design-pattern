public class NBank implements stretergy{
    String nbank="";
    public NBank(){
        nbank="Pay by UPI....";
    }
    public String pay()
    {
        return nbank;
    }
}