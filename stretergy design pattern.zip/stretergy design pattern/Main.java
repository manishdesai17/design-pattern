public class Main {
    public static void main(String[] args) {
        Context c=new Context();
        c.setPaymentStretergy(new UPI());
        System.out.println(c.dopayment());
    }
}
